import React from "react";
import Itemcard from "./itemcard";
import data from "./data";
import { Carousel } from "react-bootstrap";
import img10 from './img/img10.png';
import pic11 from './img/pic11.jpg';
import pic4 from './img/pic4.jpg';
import pic5 from './img/pic5.jpg';
import img12 from './img/img12.png';
import './home.css';

const Home=()=>{
 
    return (
    
        <Carousel className="images">
        <Carousel.Item>
          <img
            className="d-block w-100 "
            src={pic11}
            alt="First slide"
          />
          <Carousel.Caption>
            <h3></h3>
            <p></p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src={pic4}
            alt="Second slide"
          />
      
          <Carousel.Caption>
            <h3></h3>
            <p></p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src={pic5}
            alt="Third slide"
          />
      
          <Carousel.Caption>
            <h3></h3>
            <p></p>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>
    )
}

export default Home;
import React from "react";
import { Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import {useCart} from'react-use-cart';
import viewproduct from "./viewproduct";


 const Itemcard=(props)=>{
   const {addItem}=useCart();
   
     return(
         <div className="col-11 col-md-6  col-lg-3 mx-0 mb-4">
             <div class="card p-0 overflow-hidden h-100 w-30 shadow" >
  <img src={props.img} class="card-img-top img-fluid" />
  <div class="card-body text-center ">
    <h5 class="card-title">{props.title}</h5>
    <h5 class="card-title"> $ {props.price}</h5>
    <p class="card-text">{props.desc}</p>
    <Button className="btn btn-success" 
    onClick={()=>addItem(props.item)}
    >Add to Cart</Button> <br></br><br></br>
    
<Link to="/payment">Buy Now</Link>
  </div>
</div>
         </div>
         
     )
 }


 export default Itemcard;
import React from 'react';
import data from './data';
import Itemcard from './itemcard'
function viewproduct(){
    return(
        <div className="row justify-contetnt-center">
        {data.productData.map((item,index)=>{
            return(
                <Itemcard 
                img={item.img} 
                title={item.title}
                 desc={item.desc} 
                 price={item.price}
                  item={item} 
                  key={index} 
                  />
            )
        })}
    


    </div>
    )

}
export default viewproduct;
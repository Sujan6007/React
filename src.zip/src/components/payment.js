import React, { Component } from "react";

 class Payment extends Component{
    
     render(){
         return(
         <div>
             hello
         </div>
         )}
    
 }
export default Payment;
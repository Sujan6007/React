import React, { Component } from 'react';
import axios from 'axios';
import './Register.css';
class Register extends Component {
    constructor(props) {
        super(props);
        this.state = {
            id: 0,
            name: '',
            password: '',
            emailid:' ',
            mobilenumber: ' '
        }
    }

    handleChange = event => {
        this.setState({ [event.target.name]: event.target.value })
    }
    handleSubmit = event => {
        event.preventDefault()
        axios.post('http://localhost:8088/send', this.state)
            .then(res => {
                console.log(res.data)
            })
            .catch(err => {
                console.log(err)
            })
    }
    render() {
        const { id, name, password,emailid,mobilenumber } = this.state
        return (
            <div >
                <form onSubmit={this.handleSubmit}>
                    <div>
                        <label htmlFor="Id" >ID</label>
                        <input type="text" name="id" id="Id" value={id} onChange={this.handleChange} />
                    </div>
                    <br />
                    <div>
                        <label htmlFor="na">Name</label>
                        <input type="text" name="name" id="na" value={name} onChange={this.handleChange} />
                    </div>
                    <br />
                    <div>
                        <label htmlFor="ci">emailid</label>
                        <input type="text" name="emailid" id="ci" value={emailid} onChange={this.handleChange} />
                    </div>
                    <br />
                    <div>
                        <label htmlFor="pa">password</label>
                        <input type="text" name="password" id="pa" value={password} onChange={this.handleChange} />
                    </div>
                    <br />
                    <div>
                        <label htmlFor='mo'>Mobile</label>
                        <input type="text" name="mobilenumber" id="mo" value={mobilenumber} onChange={this.handleChange} />
                    </div>
                    <br />
                    <div>
                        <input type="submit" value="register" />
                        <input type="reset" value="clear" />
                    </div>
                </form>
            </div>
        );
    }
}
export default Register;

import React, { Component } from "react";
class Footer extends Component{
render(){
return(
<div class="container">
<footer class="py-5">
<div class="row">
<div class="col-2">
<h5>Section</h5>
<ul class="nav flex-column">
<li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Home</a></li>
<li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Features</a></li>
<li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Pricing</a></li>
<li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">FAQs</a></li>
<li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">About</a></li>
</ul>
</div> <div class="col-2">
<h5>Section</h5>
<ul class="nav flex-column">
<li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Home</a></li>
<li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Features</a></li>
<li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Pricing</a></li>
<li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">FAQs</a></li>
<li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">About</a></li>
</ul>
</div> <div class="col-2">
<h5>Section</h5>
<ul class="nav flex-column">
<li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Home</a></li>
<li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Features</a></li>
<li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">Pricing</a></li>
<li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">FAQs</a></li>
<li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-muted">About</a></li>
</ul>
</div> <div class="col-4 offset-1">
<form>
<h5>Subscribe to our newsletter</h5>
<p>Monthly digest of whats new and exciting from us.</p>
<div class="d-flex w-100 gap-2">
<label for="newsletter1" class="visually-hidden">Email address</label>
<input id="newsletter1" type="text" class="form-control" placeholder="Email address"/>
<button class="btn btn-primary" type="button">Subscribe</button>
</div>
</form>
</div>
</div> <div class="d-flex justify-content-between py-4 my-4 border-top">
<p>&copy; 2021 Company, Inc. All rights reserved.</p>
<ul class="list-unstyled d-flex">
<li class="ms-3"><a class="link-dark" href="#"><svg class="bi" width="24" height="24"></svg></a></li>
<li class="ms-3"><a class="link-dark" href="#"><svg class="bi" width="24" height="24"></svg></a></li>
<li class="ms-3"><a class="link-dark" href="#"><svg class="bi" width="24" height="24"></svg></a></li>
</ul>
</div>
</footer>
</div>
)
}
}export default Footer;

// import React from "react"
// import { Container, Row, Col } from "reactstrap"
// import { Link } from "react-router-dom"

// import "./footer.css"

// export default function Footer() {
//   return (
//     <footer className="footer-section">
//       <Container>
//         <Row>
//           <Col lg="4">
//             <div className="footer-left">
//               <div className="footer-logo">
//                 <Link to="/" className="navbar-brand text-light">
//                   <span>e</span>-shop
//                 </Link>
//               </div>
//               <ul>
//                 <li>
//                   <i className="fa fa-map-marker"></i> 60-49 Road 11378 Nairobi
//                 </li>
//                 <li>
//                   <i className="fa fa-phone"></i>{" "}
//                   <a href="tel:+254 746792699">+254 746792699</a>
//                 </li>
//                 <li>
//                   <i className="fa fa-envelope"></i>{" "}
//                   <a href="mailto:muriithijames556@gmail.com">
//                     muriithijames556@gmail.com
//                   </a>
//                 </li>
//               </ul>
//               <div className="footer-social">
//                 <Link to="/">
//                   <i className="fa fa-facebook"></i>
//                 </Link>
//                 <Link to="/">
//                   <i className="fa fa-instagram"></i>
//                 </Link>
//                 <Link to="/">
//                   <i className="fa fa-twitter"></i>
//                 </Link>
//                 <Link to="/">
//                   <i className="fa fa-pinterest"></i>
//                 </Link>
//               </div>
//             </div>
//           </Col>
//           <Col lg="4">
//             <div className="footer-widget">
//               <h5>Sitemap</h5>
//               <ul>
//                 <li>
//                   <Link to="/">Home</Link>
//                 </li>
//                 <li>
//                   <Link to="/">Contact</Link>
//                 </li>
//                 <li>
//                   <Link to="/">Shopping Cart</Link>
//                 </li>
//                 <li>
//                   <Link to="/">About Us</Link>
//                 </li>
//               </ul>
//             </div>
//           </Col>
//           <Col lg="4">
//             <div className="newslatter-item">
//               <h5>Join Our Newsletter Now</h5>
//               <p>
//                 Get E-mail updates about our latest shop and special offers.
//               </p>
//               <form action="#" className="subscribe-form">
//                 <input type="email" placeholder="Enter Your Mail" />
//                 <button className="btn">Subscribe</button>
//               </form>
//             </div>
//           </Col>
//         </Row>
//       </Container>
//       <div className="copyright-reserved">
//         <div className="container">
//           <div className="row">
//             <div className="col-lg-12">
//               <div className="copyright-text">
//                 Copyright © {new Date().getFullYear()} All rights reserved
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </footer>
//   )
// }

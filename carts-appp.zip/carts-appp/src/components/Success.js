import React from 'react';
import "./Success.css"

const Success = () => {

    return (
      <div className='center'>
      
        <div className='order'>
    
        <div className='card'>
        <div className='card1'>
          <i className='i'>✓</i>
        </div>
          <h1 className='h1'>Success</h1> 
          <p className='p'>We received your purchase request;<br/> Transaction Id : #45678932</p>
        </div>

        </div>
        </div>
       
        )
    }

export default Success;
    